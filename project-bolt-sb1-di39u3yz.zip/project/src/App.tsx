import StudyQuest from './components/StudyQuest';

function App() {
  return <StudyQuest />;
}

export default App;